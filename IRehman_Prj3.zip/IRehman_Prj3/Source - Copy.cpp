#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

/*
 * Class: CMSC140 CRN 22888
 * Instructor: Farnaz Eivazi
 * Project 5
 * Computer/Platform/Compiler:Visual Basic C++
 * Description: (hotel room charge program)
 * Due Date: 10/31/2022
 * I pledge that I have completed the programming assignment independently.
   I have not copied the code from a student or any source.
   I have not given my code to any student.
   Print your Name here: _Ilyas Rehman_

*/

int main() {
	//Variables****************************
	const int SINGLER = 60, DOUBLER = 75, KINGR = 100, SUITER = 150, MINF = 1, MAXF = 5, MINR = 1, MAXR = 30, projNum = 3;
	const string name = "ILYAS REHMAN", due = "10/31/2022";
	int floors, i, totalR = 0, singleIn, doubleIn, kingIn, suiteIn, singleTot = 0, doubleTot = 0, kingTot = 0, suiteTot = 0, totalAcc = 0, compare = 100, compareF, rooms;
	double totalMon, rate;
	string loca;
	//*************************************

	//Main Code****************************
	//title print out
	cout << "_________________________________________\n            BlueMont Hotel                  \n_________________________________________" << endl;
	//request for location
	cout << "Enter the location of this hotel chain:";
	getline(cin, loca);

	//repeats this piece of code if floors is not between 1 or 5
	do {
		//request for number of floors
		cout << "Enter total number of floors of the hotel:";
		cin >> floors;
		//prints out an error message if floors is not between 1 or 5 then loops the code if floors is not between 1 or 5
		if (floors < MINF or floors > MAXF) {
			cout << "number of floors should be between 1 and 5 !! please try again\n" << endl;
		}
	} while (floors > MAXF or floors < MINF);
	//repeats the code depending on how many floors they input
	for (i = 1; i <= floors; i++) {
		//repeats this piece of code if floors is not between 1 or the amount of rooms this floor has
		do {
			//repeats this piece of code if floors is not between 1 or 30
			do {
				cout << "\nEnter total number of rooms in the " << i << "th Floor:";
				cin >> rooms;
				//prints out an error message if floors is not between 1 or 30
				if (rooms < MINR or rooms > MAXR) {
					cout << "\nnumber of rooms should be between 1 and 30 !! please try again" << endl;
				}
				//loops the code if floors is not between 1 or 5
				} while (rooms > MAXR or rooms < MINR);
				//requests for number of rooms are being used between each category
				cout << "How many SINGLE rooms are accupied in the " << i << "th floor:";
				cin >> singleIn;
				cout << "How many DOUBLE rooms are accupied in the " << i << "th floor:";
				cin >> doubleIn;
				cout << "How many KING rooms are accupied in the " << i << "th floor:";
				cin >> kingIn;
				cout << "How many SUITE rooms are accupied in the " << i << "th floor:";
				cin >> suiteIn;
				//establishes the lowest total room count
				if (rooms < compare) {
					if (singleIn + doubleIn + kingIn + suiteIn <= rooms) {
						compare = rooms;
					}
					compareF = i;
				}
				//prints out an error message if floors is not between 1 or the amount of rooms this floor has
				if (singleIn + doubleIn + kingIn + suiteIn > rooms) {
					cout << "\nnumber of floors should be between 1 and " << rooms << " !! please try again" << endl;
				}
		//loops the code if floors is not between 1 or the amount of rooms this floor has
		} while (singleIn + doubleIn + kingIn + suiteIn > rooms);

		//totals of all the rooms occupied
		singleTot += singleIn;
		doubleTot += doubleIn;
		kingTot += kingIn;
		suiteTot += suiteIn;
		totalR += rooms;
	}
	//complete total of the number of rooms occupied
	totalAcc += singleTot + doubleTot + kingTot + suiteTot;
	//prints out the sign for how much each room costs a night
	cout << "\n________________________________________________________________________________\n                      BlueMont Hotel located in " << loca << "\n                        TODAY'S ROOM RATES(US$/night)\n         Single Room         Double Room        King Room        Suite Room\n                  60                  75              100               150\n________________________________________________________________________________" << endl;
	//total of money that is income for that day
	totalMon = singleTot * SINGLER + doubleTot * DOUBLER + kingTot * KINGR + suiteTot * SUITER;
	//prints out general information
	printf("            Hotel Income:           $%.2f\n", totalMon);
	cout << "        Total # of rooms:          " << totalR << endl;
	cout << "  Total # Occupied Rooms:          " << totalAcc << endl;
	cout << "Total # UnOccupied Rooms:          " << totalR - totalAcc << endl;
	rate = (static_cast<double>(totalAcc) / static_cast<double>(totalR))*100;
	printf("           Occupancy rate       %.2f", rate); 
	cout << "%\n" << endl;

	cout << compareF << "th Floor with " << compare << " rooms, has the least number of rooms." << endl;
	//if the rate of Occupied rooms that day is below 60 then it will remind to improve it
	if (rate < 60) {
		cout << "Need to improve Hotel occupancy rate!!" << endl;
	}
	//side info
	cout << "\nThank you for testing my program!!\nPROGRAMMER: " << name << "\n CMSC140 Common Project: " << projNum << "\nDue Date : " << due << "\n" << endl;

	system("pause");
	return 0;
	//*************************************
}